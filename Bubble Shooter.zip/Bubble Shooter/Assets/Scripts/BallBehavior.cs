﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallBehavior : MonoBehaviour {

	public Material[] mat;
	//public Renderer CanonRenderer;

	public bool isExploding = false;
	public int CurrentlyCollidingSameColor = 0;
	public List<Transform> AllSameColorBallsAreColliding = new List<Transform> ();


	// Use this for initialization
	void Start () {


	}
	
	// Update is called once per frame
	void Update () {


	}
	void OnCollisionEnter(Collision col)

	{
		//col.rigidbody.velocity = new Vector3 (0, 0, 0);


		if((col.transform.tag == "wall") || (col.transform.tag == "ball"))
		{
			GetComponent<Rigidbody>().isKinematic = true;
			GetComponent<AudioSource> ().Play ();


		}
		if(col.transform.tag == "ball")
		{

			if (GetComponent<Renderer>().material.color == col.transform.GetComponent<Renderer>().material.color)
			{
				CurrentlyCollidingSameColor++;
				AllSameColorBallsAreColliding.Add(col.transform);
				if (CurrentlyCollidingSameColor > 1) 
				{
					//Explode other balls
					//Explode current ball..myself
					Explode();
				}

				Debug.Log ("Same!");
			}

		}
		//collision with another ball?

		//Same material as me?

	}
	public void Explode()
	{
		Debug.Log ("EXPLODE");

		isExploding = true;
		foreach (Transform ball in AllSameColorBallsAreColliding) 
		{
			if(ball.GetComponent<BallBehavior>().isExploding == false)
			ball.GetComponent < BallBehavior> ().Explode ();
		}

		Destroy (gameObject);
	}
		




}
